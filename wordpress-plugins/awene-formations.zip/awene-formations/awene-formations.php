<?php
/**
 * Plugin Name: AWENE Formations
 * Description: Adds a managed Formation content type and public REST API for the AWENE headless site.
 * Version: 1.0.0
 * Author: AWENE
 * Text Domain: awene-formations
 */

if (!defined('ABSPATH')) {
    exit;
}

final class Awene_Formations_Plugin
{
    private const POST_TYPE = 'formation';
    private const NONCE_ACTION = 'awene_formation_save_meta';
    private const NONCE_NAME = 'awene_formation_meta_nonce';

    private const META_FIELDS = [
        'short_description' => '_awene_formation_short_description',
        'start_date' => '_awene_formation_start_date',
        'start_time' => '_awene_formation_start_time',
        'end_date' => '_awene_formation_end_date',
        'end_time' => '_awene_formation_end_time',
        'format' => '_awene_formation_format',
        'location' => '_awene_formation_location',
        'online_link' => '_awene_formation_online_link',
        'language' => '_awene_formation_language',
        'audience' => '_awene_formation_audience',
        'capacity_total' => '_awene_formation_capacity_total',
        'capacity_remaining' => '_awene_formation_capacity_remaining',
        'registration_link' => '_awene_formation_registration_link',
        'status' => '_awene_formation_status',
        'featured' => '_awene_formation_featured',
        'crm_tag' => '_awene_formation_crm_tag',
        'internal_notes' => '_awene_formation_internal_notes',
    ];

    private const FORMATS = [
        'online' => 'En ligne',
        'presentiel' => 'Présentiel',
        'hybride' => 'Hybride',
    ];

    private const LANGUAGES = [
        'fr' => 'Français',
        'ar' => 'Arabe',
        'en' => 'Anglais',
    ];

    private const AUDIENCES = [
        'particuliers' => 'Particuliers',
        'entreprises' => 'Entreprises',
        'professionnels' => 'Professionnels de santé et bien-être',
    ];

    private const STATUSES = [
        'draft_custom' => 'Brouillon',
        'upcoming' => 'À venir',
        'full' => 'Complet',
        'completed' => 'Terminé',
        'cancelled' => 'Annulé',
    ];

    public static function init(): void
    {
        add_action('init', [self::class, 'register_content']);
        add_action('init', [self::class, 'register_meta']);
        add_action('add_meta_boxes', [self::class, 'add_meta_boxes']);
        add_action('save_post_' . self::POST_TYPE, [self::class, 'save_meta']);
        add_action('rest_api_init', [self::class, 'register_rest_routes']);
        add_filter('manage_' . self::POST_TYPE . '_posts_columns', [self::class, 'columns']);
        add_action('manage_' . self::POST_TYPE . '_posts_custom_column', [self::class, 'column_content'], 10, 2);
        add_filter('manage_edit-' . self::POST_TYPE . '_sortable_columns', [self::class, 'sortable_columns']);
        add_action('pre_get_posts', [self::class, 'admin_orderby']);
        add_action('restrict_manage_posts', [self::class, 'admin_filters']);
        add_action('pre_get_posts', [self::class, 'apply_admin_filters']);
        add_shortcode('awene_formations', [self::class, 'shortcode']);
    }

    public static function activate(): void
    {
        self::register_content();
        flush_rewrite_rules();
    }

    public static function deactivate(): void
    {
        flush_rewrite_rules();
    }

    public static function register_content(): void
    {
        register_post_type(self::POST_TYPE, [
            'labels' => [
                'name' => 'Formations',
                'singular_name' => 'Formation',
                'add_new_item' => 'Ajouter une formation',
                'edit_item' => 'Modifier la formation',
                'new_item' => 'Nouvelle formation',
                'view_item' => 'Voir la formation',
                'search_items' => 'Rechercher des formations',
                'not_found' => 'Aucune formation trouvée',
                'menu_name' => 'AWENE Formations',
            ],
            'public' => true,
            'show_in_rest' => true,
            'rest_base' => 'formations',
            'menu_icon' => 'dashicons-welcome-learn-more',
            'supports' => ['title', 'editor', 'thumbnail', 'revisions'],
            'has_archive' => false,
            'rewrite' => ['slug' => 'formations'],
        ]);
    }

    public static function register_meta(): void
    {
        foreach (self::META_FIELDS as $public_key => $meta_key) {
            $type = 'string';

            if (in_array($public_key, ['capacity_total', 'capacity_remaining'], true)) {
                $type = 'integer';
            } elseif ($public_key === 'featured') {
                $type = 'boolean';
            } elseif ($public_key === 'audience') {
                $type = 'array';
            }

            register_post_meta(self::POST_TYPE, $meta_key, [
                'type' => $type,
                'single' => true,
                'show_in_rest' => false,
                'auth_callback' => static function () {
                    return current_user_can('edit_posts');
                },
                'sanitize_callback' => [self::class, 'sanitize_meta_value'],
            ]);
        }
    }

    public static function sanitize_meta_value($value, string $meta_key)
    {
        $field = array_search($meta_key, self::META_FIELDS, true);

        if ($field === false) {
            return '';
        }

        switch ($field) {
            case 'short_description':
            case 'internal_notes':
                return sanitize_textarea_field((string) $value);

            case 'start_date':
            case 'end_date':
                return self::sanitize_date((string) $value);

            case 'start_time':
            case 'end_time':
                return self::sanitize_time((string) $value);

            case 'format':
                return self::sanitize_whitelist((string) $value, self::FORMATS, 'online');

            case 'language':
                return self::sanitize_whitelist((string) $value, self::LANGUAGES, 'fr');

            case 'status':
                return self::sanitize_whitelist((string) $value, self::STATUSES, 'upcoming');

            case 'audience':
                return self::sanitize_audience($value);

            case 'capacity_total':
            case 'capacity_remaining':
                return self::sanitize_optional_integer($value);

            case 'online_link':
            case 'registration_link':
                return esc_url_raw((string) $value);

            case 'featured':
                return (bool) $value;

            case 'location':
            case 'crm_tag':
            default:
                return sanitize_text_field((string) $value);
        }
    }

    public static function add_meta_boxes(): void
    {
        add_meta_box(
            'awene_formation_details',
            'Détails de la formation',
            [self::class, 'render_details_box'],
            self::POST_TYPE,
            'normal',
            'high'
        );
    }

    public static function render_details_box(WP_Post $post): void
    {
        wp_nonce_field(self::NONCE_ACTION, self::NONCE_NAME);

        $values = self::meta_values($post->ID);
        $audience = is_array($values['audience']) ? $values['audience'] : [];
        ?>
        <style>
            .awene-formations-section { border: 1px solid #dcdcde; border-radius: 8px; margin: 0 0 18px; padding: 16px; background: #fff; }
            .awene-formations-section h3 { margin: 0 0 14px; font-size: 14px; }
            .awene-formations-grid { display: grid; gap: 16px; grid-template-columns: repeat(2, minmax(0, 1fr)); }
            .awene-formations-grid label, .awene-formations-section > label { display: block; font-weight: 600; margin-bottom: 6px; }
            .awene-formations-grid input, .awene-formations-grid select, .awene-formations-section textarea { width: 100%; }
            .awene-formations-full { grid-column: 1 / -1; }
            .awene-formations-help { color: #646970; display: block; font-size: 12px; margin-top: 4px; }
            .awene-formations-checks label { font-weight: 400; margin-right: 18px; }
            @media (max-width: 782px) { .awene-formations-grid { grid-template-columns: 1fr; } }
        </style>

        <div class="awene-formations-section">
            <h3>Description courte</h3>
            <label for="awene_formation_short_description">Résumé affiché sur le site</label>
            <textarea id="awene_formation_short_description" name="awene_formation_meta[short_description]" rows="4"><?php echo esc_textarea((string) $values['short_description']); ?></textarea>
        </div>

        <div class="awene-formations-section">
            <h3>Planning</h3>
            <div class="awene-formations-grid">
                <?php self::field('start_date', 'Date de début', 'date', $values['start_date']); ?>
                <?php self::field('start_time', 'Heure de début', 'time', $values['start_time']); ?>
                <?php self::field('end_date', 'Date de fin', 'date', $values['end_date']); ?>
                <?php self::field('end_time', 'Heure de fin', 'time', $values['end_time']); ?>
            </div>
        </div>

        <div class="awene-formations-section">
            <h3>Format et lieu</h3>
            <div class="awene-formations-grid">
                <p>
                    <label for="awene_formation_format">Format</label>
                    <select id="awene_formation_format" name="awene_formation_meta[format]">
                        <?php self::options(self::FORMATS, (string) $values['format']); ?>
                    </select>
                </p>
                <?php self::field('location', 'Lieu', 'text', $values['location']); ?>
                <?php self::field('online_link', 'Lien en ligne', 'url', $values['online_link'], 'awene-formations-full'); ?>
            </div>
            <span class="awene-formations-help">Si le format est présentiel ou hybride, le lieu est recommandé.</span>
        </div>

        <div class="awene-formations-section">
            <h3>Public et langue</h3>
            <div class="awene-formations-grid">
                <p>
                    <label for="awene_formation_language">Langue</label>
                    <select id="awene_formation_language" name="awene_formation_meta[language]">
                        <?php self::options(self::LANGUAGES, (string) $values['language']); ?>
                    </select>
                </p>
                <p>
                    <label>Public cible</label>
                    <span class="awene-formations-checks">
                        <?php foreach (self::AUDIENCES as $key => $label) : ?>
                            <label>
                                <input type="checkbox" name="awene_formation_meta[audience][]" value="<?php echo esc_attr($key); ?>" <?php checked(in_array($key, $audience, true)); ?> />
                                <?php echo esc_html($label); ?>
                            </label>
                        <?php endforeach; ?>
                    </span>
                </p>
            </div>
        </div>

        <div class="awene-formations-section">
            <h3>Capacité</h3>
            <div class="awene-formations-grid">
                <?php self::field('capacity_total', 'Nombre total de places', 'number', $values['capacity_total']); ?>
                <?php self::field('capacity_remaining', 'Places restantes', 'number', $values['capacity_remaining']); ?>
            </div>
        </div>

        <div class="awene-formations-section">
            <h3>Inscription et CRM</h3>
            <div class="awene-formations-grid">
                <?php self::field('registration_link', 'Lien d’inscription', 'url', $values['registration_link']); ?>
                <?php self::field('crm_tag', 'CRM tag', 'text', $values['crm_tag']); ?>
                <p>
                    <label for="awene_formation_status">Statut</label>
                    <select id="awene_formation_status" name="awene_formation_meta[status]">
                        <?php self::options(self::STATUSES, (string) $values['status']); ?>
                    </select>
                </p>
                <p>
                    <label>
                        <input type="checkbox" name="awene_formation_meta[featured]" value="1" <?php checked((bool) $values['featured']); ?> />
                        Formation mise en avant
                    </label>
                </p>
            </div>
        </div>

        <div class="awene-formations-section">
            <h3>Notes internes</h3>
            <label for="awene_formation_internal_notes">Notes privées, non exposées dans l’API publique</label>
            <textarea id="awene_formation_internal_notes" name="awene_formation_meta[internal_notes]" rows="5"><?php echo esc_textarea((string) $values['internal_notes']); ?></textarea>
        </div>
        <?php
    }

    private static function field(string $key, string $label, string $type, $value, string $class = ''): void
    {
        printf(
            '<p class="%5$s"><label for="awene_formation_%1$s">%2$s</label><input id="awene_formation_%1$s" type="%3$s" name="awene_formation_meta[%1$s]" value="%4$s" min="0" /></p>',
            esc_attr($key),
            esc_html($label),
            esc_attr($type),
            esc_attr((string) $value),
            esc_attr($class)
        );
    }

    private static function options(array $options, string $current): void
    {
        foreach ($options as $value => $label) {
            printf(
                '<option value="%1$s" %3$s>%2$s</option>',
                esc_attr((string) $value),
                esc_html((string) $label),
                selected($current, (string) $value, false)
            );
        }
    }

    public static function save_meta(int $post_id): void
    {
        if (
            !isset($_POST[self::NONCE_NAME]) ||
            !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST[self::NONCE_NAME])), self::NONCE_ACTION) ||
            (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) ||
            !current_user_can('edit_post', $post_id)
        ) {
            return;
        }

        $input = isset($_POST['awene_formation_meta']) && is_array($_POST['awene_formation_meta'])
            ? wp_unslash($_POST['awene_formation_meta'])
            : [];

        $input['featured'] = !empty($input['featured']);
        $input['audience'] = isset($input['audience']) && is_array($input['audience']) ? $input['audience'] : [];

        $total = self::sanitize_optional_integer($input['capacity_total'] ?? '');
        $remaining = self::sanitize_optional_integer($input['capacity_remaining'] ?? '');

        if ($total !== '' && $remaining !== '' && $remaining > $total) {
            $remaining = $total;
        }

        $input['capacity_total'] = $total;
        $input['capacity_remaining'] = $remaining;

        foreach (self::META_FIELDS as $key => $meta_key) {
            $value = $input[$key] ?? '';
            update_post_meta($post_id, $meta_key, self::sanitize_meta_value($value, $meta_key));
        }
    }

    public static function register_rest_routes(): void
    {
        $collection_args = [
            'status' => ['sanitize_callback' => 'sanitize_key'],
            'format' => ['sanitize_callback' => 'sanitize_key'],
            'language' => ['sanitize_callback' => 'sanitize_key'],
            'audience' => ['sanitize_callback' => 'sanitize_key'],
            'featured' => ['sanitize_callback' => 'rest_sanitize_boolean'],
            'upcoming_only' => [
                'default' => false,
                'sanitize_callback' => 'rest_sanitize_boolean',
            ],
            'limit' => [
                'default' => 20,
                'sanitize_callback' => 'absint',
            ],
            'page' => [
                'default' => 1,
                'sanitize_callback' => 'absint',
            ],
        ];

        register_rest_route('awene/v1', '/formations', [
            'methods' => WP_REST_Server::READABLE,
            'permission_callback' => '__return_true',
            'args' => $collection_args,
            'callback' => [self::class, 'rest_formations'],
        ]);

        register_rest_route('awene/v1', '/formations/(?P<id>\d+)', [
            'methods' => WP_REST_Server::READABLE,
            'permission_callback' => '__return_true',
            'args' => [
                'id' => [
                    'required' => true,
                    'sanitize_callback' => 'absint',
                ],
            ],
            'callback' => [self::class, 'rest_formation'],
        ]);
    }

    public static function rest_formations(WP_REST_Request $request): WP_REST_Response
    {
        $limit = min(100, max(1, (int) $request->get_param('limit')));
        $page = max(1, (int) $request->get_param('page'));
        $meta_query = self::rest_meta_query($request);

        $query = new WP_Query([
            'post_type' => self::POST_TYPE,
            'post_status' => 'publish',
            'posts_per_page' => $limit,
            'paged' => $page,
            'meta_query' => $meta_query,
        ]);

        $items = array_map(
            static fn (WP_Post $post) => self::formation_payload($post->ID),
            $query->posts
        );

        usort($items, [self::class, 'sort_payloads']);

        $response = rest_ensure_response($items);
        $response->header('X-WP-Total', (string) $query->found_posts);
        $response->header('X-WP-TotalPages', (string) $query->max_num_pages);

        return $response;
    }

    public static function rest_formation(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $post_id = absint($request->get_param('id'));
        $post = get_post($post_id);

        if (!$post || $post->post_type !== self::POST_TYPE || $post->post_status !== 'publish') {
            return new WP_Error('awene_formation_not_found', 'Formation not found.', ['status' => 404]);
        }

        return rest_ensure_response(self::formation_payload($post_id));
    }

    private static function rest_meta_query(WP_REST_Request $request): array
    {
        $meta_query = [];

        $status = (string) $request->get_param('status');
        if ($status !== '' && isset(self::STATUSES[$status])) {
            $meta_query[] = [
                'key' => self::META_FIELDS['status'],
                'value' => $status,
                'compare' => '=',
            ];
        }

        $format = (string) $request->get_param('format');
        if ($format !== '' && isset(self::FORMATS[$format])) {
            $meta_query[] = [
                'key' => self::META_FIELDS['format'],
                'value' => $format,
                'compare' => '=',
            ];
        }

        $language = (string) $request->get_param('language');
        if ($language !== '' && isset(self::LANGUAGES[$language])) {
            $meta_query[] = [
                'key' => self::META_FIELDS['language'],
                'value' => $language,
                'compare' => '=',
            ];
        }

        $audience = (string) $request->get_param('audience');
        if ($audience !== '' && isset(self::AUDIENCES[$audience])) {
            $meta_query[] = [
                'key' => self::META_FIELDS['audience'],
                'value' => '"' . $audience . '"',
                'compare' => 'LIKE',
            ];
        }

        if ($request->has_param('featured')) {
            $meta_query[] = [
                'key' => self::META_FIELDS['featured'],
                'value' => rest_sanitize_boolean($request->get_param('featured')) ? '1' : '0',
                'compare' => '=',
            ];
        }

        if ($request->get_param('upcoming_only')) {
            $meta_query[] = [
                'key' => self::META_FIELDS['start_date'],
                'value' => current_time('Y-m-d'),
                'compare' => '>=',
                'type' => 'DATE',
            ];
        }

        if (count($meta_query) > 1) {
            $meta_query['relation'] = 'AND';
        }

        return $meta_query;
    }

    private static function formation_payload(int $post_id): array
    {
        $meta = self::meta_values($post_id);
        $audience = is_array($meta['audience']) ? array_values($meta['audience']) : [];
        $image_id = get_post_thumbnail_id($post_id);

        return [
            'id' => $post_id,
            'title' => get_the_title($post_id),
            'slug' => get_post_field('post_name', $post_id),
            'excerpt' => (string) $meta['short_description'],
            'content' => apply_filters('the_content', get_post_field('post_content', $post_id)),
            'start_date' => (string) $meta['start_date'],
            'start_time' => (string) $meta['start_time'],
            'end_date' => (string) $meta['end_date'],
            'end_time' => (string) $meta['end_time'],
            'date_label' => self::date_label($meta),
            'time_label' => self::time_label($meta),
            'format' => (string) $meta['format'],
            'format_label' => self::FORMATS[(string) $meta['format']] ?? self::FORMATS['online'],
            'location' => (string) $meta['location'],
            'online_link' => (string) $meta['online_link'],
            'language' => (string) $meta['language'],
            'language_label' => self::LANGUAGES[(string) $meta['language']] ?? self::LANGUAGES['fr'],
            'audience' => $audience,
            'audience_labels' => array_map(static fn (string $key) => self::AUDIENCES[$key] ?? $key, $audience),
            'capacity_total' => $meta['capacity_total'] === '' ? null : absint($meta['capacity_total']),
            'capacity_remaining' => $meta['capacity_remaining'] === '' ? null : absint($meta['capacity_remaining']),
            'remaining_seats' => $meta['capacity_remaining'] === '' ? null : absint($meta['capacity_remaining']),
            'registration_link' => (string) $meta['registration_link'],
            'registration_url' => (string) $meta['registration_link'],
            'status' => (string) $meta['status'],
            'status_label' => self::STATUSES[(string) $meta['status']] ?? self::STATUSES['upcoming'],
            'featured' => (bool) $meta['featured'],
            'cover_image' => self::cover_image($image_id, $post_id),
            'image' => self::cover_image($image_id, $post_id),
            'crm_tag' => (string) $meta['crm_tag'],
        ];
    }

    private static function meta_values(int $post_id): array
    {
        $values = [];

        foreach (self::META_FIELDS as $key => $meta_key) {
            $value = get_post_meta($post_id, $meta_key, true);
            $values[$key] = $value;
        }

        $values['format'] = self::sanitize_whitelist((string) ($values['format'] ?: 'online'), self::FORMATS, 'online');
        $values['language'] = self::sanitize_whitelist((string) ($values['language'] ?: 'fr'), self::LANGUAGES, 'fr');
        $values['status'] = self::sanitize_whitelist((string) ($values['status'] ?: 'upcoming'), self::STATUSES, 'upcoming');
        $values['audience'] = self::sanitize_audience($values['audience']);
        $values['featured'] = (bool) $values['featured'];

        return $values;
    }

    private static function cover_image(int|false $image_id, int $post_id): ?array
    {
        if (!$image_id) {
            return null;
        }

        return [
            'alt' => get_post_meta($image_id, '_wp_attachment_image_alt', true) ?: get_the_title($post_id),
            'thumbnail' => wp_get_attachment_image_url($image_id, 'thumbnail') ?: null,
            'medium' => wp_get_attachment_image_url($image_id, 'medium') ?: null,
            'large' => wp_get_attachment_image_url($image_id, 'large') ?: null,
            'full' => wp_get_attachment_image_url($image_id, 'full') ?: null,
        ];
    }

    private static function sort_payloads(array $a, array $b): int
    {
        $today = current_time('Y-m-d');
        $a_date = (string) ($a['start_date'] ?? '');
        $b_date = (string) ($b['start_date'] ?? '');
        $a_upcoming = $a_date !== '' && $a_date >= $today ? 0 : 1;
        $b_upcoming = $b_date !== '' && $b_date >= $today ? 0 : 1;

        if ($a_upcoming !== $b_upcoming) {
            return $a_upcoming <=> $b_upcoming;
        }

        if ($a_date === $b_date) {
            return strcmp((string) $a['title'], (string) $b['title']);
        }

        return $a_date <=> $b_date;
    }

    public static function columns(array $columns): array
    {
        $new_columns = [];

        foreach ($columns as $key => $label) {
            $new_columns[$key] = $label;

            if ($key === 'title') {
                $new_columns['awene_formation_date'] = 'Date';
                $new_columns['awene_formation_format'] = 'Format';
                $new_columns['awene_formation_language'] = 'Langue';
                $new_columns['awene_formation_status'] = 'Statut';
                $new_columns['awene_formation_places'] = 'Places';
                $new_columns['awene_formation_featured'] = 'Mise en avant';
            }
        }

        return $new_columns;
    }

    public static function column_content(string $column, int $post_id): void
    {
        $meta = self::meta_values($post_id);

        if ($column === 'awene_formation_date') {
            echo esc_html((string) ($meta['start_date'] ?: 'A venir'));
        } elseif ($column === 'awene_formation_format') {
            echo esc_html(self::FORMATS[(string) $meta['format']] ?? '');
        } elseif ($column === 'awene_formation_language') {
            echo esc_html(self::LANGUAGES[(string) $meta['language']] ?? '');
        } elseif ($column === 'awene_formation_status') {
            echo esc_html(self::STATUSES[(string) $meta['status']] ?? '');
        } elseif ($column === 'awene_formation_places') {
            $total = $meta['capacity_total'];
            $remaining = $meta['capacity_remaining'];
            echo esc_html($remaining === '' && $total === '' ? '-' : ($remaining ?: '0') . ' / ' . ($total ?: '-'));
        } elseif ($column === 'awene_formation_featured') {
            echo $meta['featured'] ? esc_html__('Oui', 'awene-formations') : esc_html__('Non', 'awene-formations');
        }
    }

    public static function sortable_columns(array $columns): array
    {
        $columns['awene_formation_date'] = 'awene_formation_date';
        return $columns;
    }

    public static function admin_orderby(WP_Query $query): void
    {
        if (!is_admin() || !$query->is_main_query()) {
            return;
        }

        if ($query->get('post_type') !== self::POST_TYPE || $query->get('orderby') !== 'awene_formation_date') {
            return;
        }

        $query->set('meta_key', self::META_FIELDS['start_date']);
        $query->set('orderby', 'meta_value');
        $query->set('meta_type', 'DATE');
    }

    public static function admin_filters(string $post_type): void
    {
        if ($post_type !== self::POST_TYPE) {
            return;
        }

        self::admin_filter_select('awene_formation_status', 'Tous les statuts', self::STATUSES);
        self::admin_filter_select('awene_formation_format', 'Tous les formats', self::FORMATS);
        self::admin_filter_select('awene_formation_language', 'Toutes les langues', self::LANGUAGES);
    }

    private static function admin_filter_select(string $name, string $placeholder, array $options): void
    {
        $current = isset($_GET[$name]) ? sanitize_key((string) wp_unslash($_GET[$name])) : '';

        printf('<select name="%1$s"><option value="">%2$s</option>', esc_attr($name), esc_html($placeholder));

        foreach ($options as $value => $label) {
            printf(
                '<option value="%1$s" %3$s>%2$s</option>',
                esc_attr((string) $value),
                esc_html((string) $label),
                selected($current, (string) $value, false)
            );
        }

        echo '</select>';
    }

    public static function apply_admin_filters(WP_Query $query): void
    {
        if (!is_admin() || !$query->is_main_query() || $query->get('post_type') !== self::POST_TYPE) {
            return;
        }

        $meta_query = (array) $query->get('meta_query');

        $filters = [
            'awene_formation_status' => ['field' => 'status', 'options' => self::STATUSES],
            'awene_formation_format' => ['field' => 'format', 'options' => self::FORMATS],
            'awene_formation_language' => ['field' => 'language', 'options' => self::LANGUAGES],
        ];

        foreach ($filters as $request_key => $config) {
            $value = isset($_GET[$request_key]) ? sanitize_key((string) wp_unslash($_GET[$request_key])) : '';

            if ($value !== '' && isset($config['options'][$value])) {
                $meta_query[] = [
                    'key' => self::META_FIELDS[$config['field']],
                    'value' => $value,
                    'compare' => '=',
                ];
            }
        }

        if ($meta_query) {
            $meta_query['relation'] = 'AND';
            $query->set('meta_query', $meta_query);
        }
    }

    public static function shortcode(array $atts = []): string
    {
        $query = new WP_Query([
            'post_type' => self::POST_TYPE,
            'post_status' => 'publish',
            'posts_per_page' => 10,
            'meta_key' => self::META_FIELDS['start_date'],
            'orderby' => 'meta_value',
            'order' => 'ASC',
        ]);

        if (!$query->have_posts()) {
            return '<p>Aucune formation programmée pour le moment.</p>';
        }

        $html = '<ul class="awene-formations-list">';

        while ($query->have_posts()) {
            $query->the_post();
            $meta = self::meta_values(get_the_ID());
            $html .= sprintf(
                '<li><strong>%1$s</strong><br><span>%2$s · %3$s · %4$s</span></li>',
                esc_html(get_the_title()),
                esc_html(self::date_label($meta)),
                esc_html(self::FORMATS[(string) $meta['format']] ?? ''),
                esc_html(self::STATUSES[(string) $meta['status']] ?? '')
            );
        }

        wp_reset_postdata();

        return $html . '</ul>';
    }

    private static function sanitize_date(string $value): string
    {
        $value = trim($value);

        if ($value === '') {
            return '';
        }

        $date = DateTime::createFromFormat('Y-m-d', $value);

        return $date && $date->format('Y-m-d') === $value ? $value : '';
    }

    private static function sanitize_time(string $value): string
    {
        $value = trim($value);

        if ($value === '') {
            return '';
        }

        return preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $value) ? $value : '';
    }

    private static function sanitize_whitelist(string $value, array $allowed, string $default): string
    {
        return isset($allowed[$value]) ? $value : $default;
    }

    private static function sanitize_audience($value): array
    {
        if (!is_array($value)) {
            return [];
        }

        return array_values(array_filter(array_map('sanitize_key', $value), static function (string $item) {
            return isset(self::AUDIENCES[$item]);
        }));
    }

    private static function sanitize_optional_integer($value): int|string
    {
        if ($value === '' || $value === null) {
            return '';
        }

        return max(0, absint($value));
    }

    private static function date_label(array $meta): string
    {
        if (empty($meta['start_date'])) {
            return 'Date à venir';
        }

        $timestamp = strtotime((string) $meta['start_date']);

        if (!$timestamp) {
            return (string) $meta['start_date'];
        }

        return date_i18n('j F Y', $timestamp);
    }

    private static function time_label(array $meta): string
    {
        $start = (string) ($meta['start_time'] ?? '');
        $end = (string) ($meta['end_time'] ?? '');

        if ($start && $end) {
            return $start . ' - ' . $end;
        }

        return $start;
    }
}

Awene_Formations_Plugin::init();
register_activation_hook(__FILE__, ['Awene_Formations_Plugin', 'activate']);
register_deactivation_hook(__FILE__, ['Awene_Formations_Plugin', 'deactivate']);
